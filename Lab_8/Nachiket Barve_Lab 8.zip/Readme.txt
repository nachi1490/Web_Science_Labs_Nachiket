Some important points relate to this Lab:

1.) Enter the Query which has all three Subject, Object and Predicate attributes in it.

2.) After hitting the submit button /getSparqlData API in the backend will be called and it will fetch the JSON from DBpedia or any endpoint that is specified.

3.) Made use of bootstrap table to display the values of Subject, predicate and object output from the endpoint

4.) Used AngularJS to bind data to the front-end. 

5.) Made use of NPM package sparql-client, which easily establishes connection to the endpoint and fetches data.

6.) All necessary error checks, indentation and comments have been added to the code.




