Some Key points :-

1.) Used Bootstrap's panel module to hold all the weather related information in the application.
2.) Used Navbar-brand class of Bootstrap for the header and footer of the app
3.) Used fakeloader.js - a lightweight JQuery template for animations of initial page load
4.) First got the lat and long coordinates from the browser using HtML5 geolocation code.
5.) Appended the latitiude and longitudes to the openweathermap API's Url.